****************************\
*MinesweeperSkeletoncodelv2.py
*by Nabil Mussa 
****************************\

import pygame

height = 1280
width = 720
fps = 60

pygame.init()
screen = pygame.display.set_mode((height, width))
clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill("grey")
    
    pygame.display.flip()
    clock.tick(fps)
pygame.quit()
