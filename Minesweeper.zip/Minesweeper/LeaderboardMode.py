from tkinter import *
import tkinter as tk
import time
import subprocess


def quitgame():
    root.destroy()
    return None

def run16by16loop():
    subprocess.run(["python", "C:\\Users\\youip\\Desktop\\uni classes year 0\\Computing Project\\Minesweeper\\Leaderboard16x16.py"])#replace with next menu screen
    root.destroy()

def run32by32loop():
    subprocess.run(["python", "C:\\Users\\youip\\Desktop\\uni classes year 0\\Computing Project\\Minesweeper\\Leaderboard32x32.py"])#replace with next menu screen
    root.destroy()

def goBack():
    subprocess.run(["python","start game.py"])
    root.destroy()

    
root=Tk()
root.title("Pick Your Difficulty")
root.geometry("1920x1080")
root.configure(bg='light grey')

easymode = PhotoImage(file="assets\\Easy-16x16.png")
hardmode = PhotoImage(file="assets\\Hard-32x32.png")
GoBack = PhotoImage(file="assets\\Go-Back.png")

b = Button(root, image=easymode, command = lambda:(run16by16loop()))
b.configure(bg='grey')
b.pack(pady=10)
    
b2 = Button(root, image=hardmode, command = lambda:[run32by32loop()])
b2.configure(bg='grey')
b2.pack(padx= 50)

b3 = Button(root, image=GoBack,command = lambda:[goBack()])
b3.configure(bg='grey')
b3.pack(padx=50, pady=150)

label = tk.Label(root, text="Which leaderboard do you want to view?", font=16,fg="black")
label.configure(bg="lightgrey")
label.pack(pady=100)






root.mainloop()