from tkinter import *
import tkinter as tk
import time
import subprocess


def quitgame():
    root.destroy()
    return None

def run16by16loop():
    subprocess.run(["python", "C:\\Users\\youip\\Desktop\\uni classes year 0\\Computing Project\\Minesweeper\\Rules screen16by16.py"])#replace with next menu screen
    root.destroy()

def run32by32loop():
    subprocess.run(["python", "C:\\Users\\youip\\Desktop\\uni classes year 0\\Computing Project\\Minesweeper\\Rules screen32by32.py"])#replace with next menu screen
    root.destroy()

root=Tk()
root.title("Pick Your Difficulty")
root.geometry("1920x1080")
root.configure(bg='light grey')

easymode = PhotoImage(file="assets\\Easy-16x16.png")
hardmode = PhotoImage(file="assets\\Hard-32x32.png")

b = Button(root, image=easymode, command = lambda:(run16by16loop()))
b.configure(bg='grey')
b.pack(pady=10)
    
b2 = Button(root, image=hardmode, command = lambda:[run32by32loop()])
b2.configure(bg='grey')
b2.pack(padx= 50, pady=50)


label = tk.Label(root, text="These modes affect the size of the grid and the amount of mines", font=16,fg="black")
label.configure(bg="lightgrey")
label.pack(pady=100)






root.mainloop()