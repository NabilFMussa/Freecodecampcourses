from tkinter import *
import time
import subprocess
from tkinter import simpledialog
import json

def quitgame():
    root.destroy()
    return None

def displayLeaderboard():

    subprocess.run(["python", "LeaderboardDisplay16x16.py"])#replace with next menu screen
    root.destroy()

def clearLeaderboard():
    try:
        with open("leaderboard data\\leaderboard.txt", "w") as file:
            file.write("")
    except FileNotFoundError:
        print(f"file not found")

def goBack():

    subprocess.run(["python", "start game.py"])
    root.destroy()

    
def readdataforsort():
    leaderboardData = []
    try:
        with open("leaderboard data\\leaderboard.txt", "r") as file:
            for line in file:
                name, valueStr = line.strip().split(":")
                value = float(valueStr.strip("{}"))
                leaderboardData.append((name.strip(), value))
            return leaderboardData
    except FileNotFoundError:
        print("File not found")
        return []
    
def sort():
    leaderboardData = readdataforsort()

    if not leaderboardData:
        return
    
    sortedLeaderboard = sorted(leaderboardData, key=lambda x: x[1])
    
    with open("leaderboard data\\leaderboard.txt", "w") as file:
        for user, value in sortedLeaderboard:
            file.write(f"{user}: {value:.2f}\n")

root=Tk()
root.title("Leaderboard")
root.geometry("1920x1080")
root.configure(bg='light grey')

sort()

Display = PhotoImage(file="assets\\Display-Leaderboard.png")
Clear = PhotoImage(file="assets\\Clear-Leaderboard.png")
GoBack = PhotoImage(file="assets\\Go-Back.png")

b = Button(root, image=Display,command = lambda:(displayLeaderboard()))
b.configure(bg='grey')
b.pack()
    
b2 = Button(root, image=Clear, command = lambda:[clearLeaderboard()])
b2.configure(bg='grey')
b2.pack(padx=50, pady=50)

b3 = Button(root, image=GoBack, command = lambda:[goBack()])
b3.configure(bg='grey')
b3.pack(padx=50, pady=250)

root.mainloop()