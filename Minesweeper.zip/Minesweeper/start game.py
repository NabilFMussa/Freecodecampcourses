from tkinter import *
import time
import subprocess

def quitgame():
    root.destroy()
    return None

def runNextScreen():
    subprocess.run(["python", "C:\\Users\\youip\\Desktop\\uni classes year 0\\Computing Project\\Minesweeper\\Difficulty screen.py"])#replace with next menu screen
    root.destroy()

def Leaderboard():
    subprocess.run(["python", "LeaderboardMode.py"])
    root.destroy()

root=Tk()
root.title("Minesweeper")
root.geometry("1920x1080")
root.configure(bg='lightgrey')
startGame = PhotoImage(file="assets\\Start-Game.png")
quitGame= PhotoImage(file="assets\\Quit.png")
leaderboard = PhotoImage(file="assets\\Leaderboard.png")

b = Button(root, text="Start Game", image=startGame,command = lambda:(runNextScreen()))
b.configure(bg='grey')
b.pack(pady= 10)
    
b2 = Button(root, text="Quit game",image=quitGame, command = lambda:[quitgame()])
b2.configure(bg='grey')
b2.pack(padx=50, pady=50)

b3 = Button(root, text="Leaderboard",image=leaderboard, command = lambda:[Leaderboard()])
b3.configure(bg='grey')
b3.pack(padx=50, pady=250)

root.mainloop()