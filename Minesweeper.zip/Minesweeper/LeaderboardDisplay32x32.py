import tkinter as tk
from tkinter import *
import json
import subprocess


def readLeaderboard():
    file_path = "leaderboard data\\leaderboard32x32.txt"
    leaderboardData = []
    try:
        with open(file_path, "r") as file:
            for line in file:
                name, valueStr = line.strip().split(":")
                value = float(valueStr.strip("{}"))
                leaderboardData.append((name.strip("{}"), value))
        return leaderboardData
    except FileNotFoundError:
        print(f"File not found")
        return []
    


def createLeaderboard():
    leaderboardData = readLeaderboard()

    def goBack():
        subprocess.run(["python", "LeaderboardMode.py"])
        root.destroy()

    if not leaderboardData:
        return
    
    root = tk.Tk()
    root.geometry("1920x1080")
    root.title("Leaderboard")
    root.configure(bg="grey")
    

    welcometotheleaderboard = PhotoImage(file="assets\\WelcometotheLeaderboard.png")
    GoBack = PhotoImage(file="assets\\Go-Back.png")
    
    title = tk.Label(root, image=welcometotheleaderboard)
    title.configure(bg="grey")
    title.pack()

    for i, (user, value) in enumerate(leaderboardData):
        label = tk.Label(root, text=f"{i+1}. {user}: {value:.2f}s", font=16,fg="white")
        label.configure(bg="grey")
        label.pack(pady=10)


    b3 = Button(root, image=GoBack,command = lambda:[goBack()])
    b3.configure(bg='grey')
    b3.pack(padx=50, pady=300)


    root.mainloop()


createLeaderboard()