from tkinter import *
import time
import subprocess
import tkinter as tk
from tkinter import simpledialog

def quitgame():
    root.destroy()
    return None

def runNextScreen():

    user = simpledialog.askstring("Player Name", "Enter Your Name:")

    with open("leaderboard data\\userTemp.txt", "w") as userName:
        userName.write(user) 

    subprocess.run(["python", "C:\\Users\\youip\\Desktop\\uni classes year 0\\Computing Project\\Minesweeper\\minesweeper_16by16.py"])#replace with next menu screen
    root.destroy()

root=Tk()
root.title("Rules")
root.geometry("1920x1080")
root.configure(bg='light grey')

quitgameimage = PhotoImage(file="assets\\Quit.png")
startgame = PhotoImage(file="assets\\Start-Game.png")

b = Button(root, image=startgame,command = lambda:(runNextScreen()))
b.configure(bg='grey')
b.pack(pady=10)
    
b2 = Button(root, image=quitgameimage, command = lambda:[quitgame()])
b2.configure(bg='grey')
b2.pack(padx=50, pady=50)

label = tk.Label(root, text="Welcome! Your goal is to clear the minefield without hitting any of the mines.", font=16,fg="black")
label.configure(bg="lightgrey")
label.pack(pady=100)

labelcont = tk.Label(root, text="Controls: \n Left click: reveals a grid \n Right click: places a flag\n Be careful you don't have infinite flags!", font=16,fg="black")
labelcont.configure(bg="lightgrey")
labelcont.pack()


root.mainloop()